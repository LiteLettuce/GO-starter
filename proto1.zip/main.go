package main

import (
	rl "github.com/gen2brain/raylib-go/raylib"
)

var (
	Jeff        rl.Texture2D
	playerDest  rl.Rectangle
	playerSrc   rl.Rectangle
	playerSpeed float32 = 3
)

func movement() {
	if rl.IsKeyDown(rl.KeyW) || rl.IsKeyDown(rl.KeyUp) {
		playerDest.Y -= playerSpeed
	}
	if rl.IsKeyDown(rl.KeyA) || rl.IsKeyDown(rl.KeyLeft) {
		playerDest.X -= playerSpeed
	}
	if rl.IsKeyDown(rl.KeyS) || rl.IsKeyDown(rl.KeyDown) {
		playerDest.Y += playerSpeed
	}
	if rl.IsKeyDown(rl.KeyD) || rl.IsKeyDown(rl.KeyRight) {
		playerDest.X += playerSpeed
	}

}

func draw() {
	rl.BeginDrawing()
	rl.ClearBackground(rl.SkyBlue)

	rl.DrawTexturePro(Jeff, playerSrc, playerDest, rl.NewVector2(playerDest.Width, playerDest.Height), 0, rl.White)

	rl.EndDrawing()
}
func unload() {
	rl.UnloadTexture(Jeff)
}

func startup() {
	rl.InitWindow(1000, 480, "Test")
	rl.SetTargetFPS(60)
	Jeff = rl.LoadTexture("image.png")
	playerSrc = rl.NewRectangle(0, 0, 58, 66)
	playerDest = rl.NewRectangle(200, 200, 100, 100)
}
func main() {
	startup()
	for !rl.WindowShouldClose() {
		draw()
		movement()
	}
	rl.CloseWindow()
	unload()
}
